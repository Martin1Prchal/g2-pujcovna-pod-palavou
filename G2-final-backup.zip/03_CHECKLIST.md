# Checklist

## Úkoly

- [x] Zadání a scope potvrzeny
- [x] Zdrojový web a vizuální reference prověřeny
- [x] Řešení a struktura navrženy
- [x] Implementace dokončena
- [x] Dokumentace aktualizována
- [x] QA dokončeno
- [x] Cleanup dokončen
- [x] Handoff připraven

## Definition of Done

- [x] Všech 7 veřejných stránek existuje
- [x] Desktop a mobile jsou responzivní
- [x] Navigace a CTA fungují
- [x] Katalog, filtry a galerie fungují
- [x] Poptávkový formulář počítá dny a jezdce
- [x] Výška >= 180 cm vyžádá hmotnost
- [x] Dovoz zobrazí místo dovozu
- [x] Obsah je centralizovaný a upravitelný v adminu
- [x] Kritické scénáře prošly testy
- [x] Nejsou známé kritické chyby
- [x] Dokumentace odpovídá skutečnosti
- [x] Všechny stránky používají jednotný sans-serif design systém
- [x] Ve viditelném UI nejsou emoji ikony
- [x] Výlet obsahuje editovatelnou Mapy.cz GPS URL a veřejné CTA
- [x] Admin umí vytvářet, řadit, skrývat a mazat výlety
- [x] Produkty, výlety, galerie a hero podporují upload obrázku ze zařízení
- [x] Responzivní Google Maps iframe a CTA jsou dostupné na homepage i Kontakt
- [x] Homepage hero používá celý nedeformovaný `<img>` bez překrytí navazující sekcí
- [x] Homepage kategorie zobrazují pouze název, popis a zvětšený obrázek bez ceny
- [x] Spodní kontakt je jeden blok s vloženou Google mapou
- [x] Půjčovna veřejně zobrazuje pouze 4 obecné kategorie, ne jednotlivé modely
- [x] Kategorie Půjčovny používají ceny z centrálního ceníku a editovatelné fotografie
- [x] Obrázky galerie se otevírají v responzivním lightboxu s klávesovým ovládáním
- [x] Kategorie na homepage vedou bez query parametrů na Půjčovnu
- [x] Veřejné označení prototypu a dokumentační odkazy na nepoužívaný hosting jsou odstraněné
- [x] Nepoužívaná logika query filtru a konfigurace dřívějšího hostingu jsou odstraněné
- [x] GitHub Pages workflow zůstává beze změny
- [x] Projekt je připravený pro další fázi Figma → Framer
- [x] Figma soubor obsahuje Cover, Foundations, Components, Desktop a Mobile
- [x] Ve Figmě je všech 7 desktopových návrhů na šířce 1440 px
- [x] Ve Figmě je všech 7 mobilních návrhů na šířce 390 px
- [x] Galerie obsahuje desktopový i mobilní Lightbox stav
- [x] Poptávka obsahuje stav jezdce s výškou >= 180 cm
- [x] Figma foundations obsahují variables, text styles a effect style
- [x] Klíčové UI prvky jsou ve Figmě vytvořené jako znovupoužitelné komponenty s Auto Layoutem
- [x] Framer stránka Ceník používá na desktopu jednotnou obsahovou osu `max-width: 1180px`
- [x] Tabletové a mobilní wrappery zůstaly při úpravě desktopu beze změny
